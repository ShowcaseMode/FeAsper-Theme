# Vanilla
[Download](https://github.com/melkypie/resource-packs/archive/sample-vanilla.zip)

THis is a sample pack that allows you to create other resource packs. Includes the default runescape textures.
<img src="https://user-images.githubusercontent.com/5113962/82244509-02b0eb00-994a-11ea-8343-0a7dd7ddaa82.png" width="765"><br/>


